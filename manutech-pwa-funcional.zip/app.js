// ===== Estado & Persistência =====
const LS_KEYS = { EQUIPS: 'manutech_equips', ORDERS: 'manutech_orders' };
let equips = JSON.parse(localStorage.getItem(LS_KEYS.EQUIPS) || '[]');
let orders = JSON.parse(localStorage.getItem(LS_KEYS.ORDERS) || '[]');
let editingEquipId = null;
let editingOrderId = null;

function saveState(){
  localStorage.setItem(LS_KEYS.EQUIPS, JSON.stringify(equips));
  localStorage.setItem(LS_KEYS.ORDERS, JSON.stringify(orders));
}

// ===== Navegação =====
function toggleMenu(){ document.getElementById('sidebar').classList.toggle('active'); }
function navigate(e){
  e.preventDefault();
  const view = e.currentTarget.dataset.view;
  document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));
  document.getElementById('view-'+view).classList.add('active');
  document.getElementById('sidebar').classList.remove('active');
  if(view==='orders'){ renderOrders(); fillEquipSelect(); }
  if(view==='equipments'){ renderEquipments(); }
  if(view==='dashboard'){ renderDashboard(); }
}

// ===== Util =====
const fmtDate = (str)=> str ? new Date(str+'T00:00:00').toLocaleDateString() : '-';
const uid = ()=> Math.random().toString(36).slice(2,9);

// ===== Equipamentos =====
function openEquipModal(id=null){
  editingEquipId = id;
  document.getElementById('equipModalTitle').textContent = id ? 'Editar Equipamento' : 'Novo Equipamento';
  const name = document.getElementById('equipName');
  const model = document.getElementById('equipModel');
  const serial = document.getElementById('equipSerial');
  const location = document.getElementById('equipLocation');
  if(id){
    const eq = equips.find(e=>e.id===id);
    name.value = eq.name; model.value = eq.model; serial.value = eq.serial; location.value = eq.location||'';
  } else { name.value=''; model.value=''; serial.value=''; location.value=''; }
  document.getElementById('equipModal').style.display='flex';
}
function closeEquipModal(){ document.getElementById('equipModal').style.display='none'; }
function saveEquip(){
  const name = document.getElementById('equipName').value.trim();
  const model = document.getElementById('equipModel').value.trim();
  const serial = document.getElementById('equipSerial').value.trim();
  const location = document.getElementById('equipLocation').value.trim();
  if(!name){ alert('Informe o nome do equipamento'); return; }
  if(editingEquipId){
    const idx = equips.findIndex(e=>e.id===editingEquipId);
    equips[idx] = {...equips[idx], name, model, serial, location};
  } else {
    equips.push({ id: uid(), name, model, serial, location, createdAt: Date.now() });
  }
  saveState(); renderEquipments(); fillEquipSelect(); closeEquipModal();
}
function deleteEquip(id){
  if(orders.some(o=>o.equipId===id)){ alert('Há ordens associadas a este equipamento. Exclua/alterne as OS antes.'); return; }
  if(confirm('Excluir equipamento?')){
    equips = equips.filter(e=>e.id!==id);
    saveState(); renderEquipments(); fillEquipSelect(); renderDashboard();
  }
}
function renderEquipments(){
  const q = document.getElementById('equipSearch').value.toLowerCase();
  const list = equips.filter(e => [e.name,e.model,e.serial].join(' ').toLowerCase().includes(q));
  const el = document.getElementById('equipList');
  if(list.length===0){ el.innerHTML = '<div class="card-full"><p>Nenhum equipamento cadastrado.</p></div>'; return; }
  const rows = list.map(e=>`
    <tr>
      <td><strong>${e.name}</strong><br><small>${e.location||'-'}</small></td>
      <td>${e.model||'-'}</td>
      <td>${e.serial||'-'}</td>
      <td>
        <button class="btn" onclick="openEquipModal('${e.id}')">Editar</button>
        <button class="btn danger" onclick="deleteEquip('${e.id}')">Excluir</button>
      </td>
    </tr>`).join('');
  el.innerHTML = `<table>
    <thead><tr><th>Nome</th><th>Modelo</th><th>Série</th><th>Ações</th></tr></thead>
    <tbody>${rows}</tbody></table>`;
}
function fillEquipSelect(){
  const select = document.getElementById('orderEquip');
  select.innerHTML = '<option value="">Selecione o equipamento</option>' + equips.map(e=>`<option value="${e.id}">${e.name}</option>`).join('');
}

// ===== Ordens =====
function openOrderModal(id=null){
  editingOrderId = id;
  document.getElementById('orderModalTitle').textContent = id ? 'Editar Ordem de Serviço' : 'Nova Ordem de Serviço';
  fillEquipSelect();
  const fields = {
    title: document.getElementById('orderTitle'),
    equip: document.getElementById('orderEquip'),
    tech: document.getElementById('orderTech'),
    date: document.getElementById('orderDate'),
    status: document.getElementById('orderStatus'),
    desc: document.getElementById('orderDesc'),
    parts: document.getElementById('orderParts'),
  };
  if(id){
    const o = orders.find(x=>x.id===id);
    fields.title.value=o.title; fields.equip.value=o.equipId; fields.tech.value=o.tech;
    fields.date.value=o.date||''; fields.status.value=o.status; fields.desc.value=o.desc||''; fields.parts.value=o.parts||'';
  } else { Object.values(fields).forEach(f=>f.value=''); fields.status.value='aberta'; }
  document.getElementById('orderModal').style.display='flex';
}
function closeOrderModal(){ document.getElementById('orderModal').style.display='none'; }
function saveOrder(){
  const title = document.getElementById('orderTitle').value.trim();
  const equipId = document.getElementById('orderEquip').value;
  const tech = document.getElementById('orderTech').value.trim();
  const date = document.getElementById('orderDate').value;
  const status = document.getElementById('orderStatus').value;
  const desc = document.getElementById('orderDesc').value.trim();
  const parts = document.getElementById('orderParts').value.trim();
  if(!title || !equipId){ alert('Informe o título e selecione um equipamento.'); return; }
  if(editingOrderId){
    const i = orders.findIndex(o=>o.id===editingOrderId);
    orders[i] = {...orders[i], title, equipId, tech, date, status, desc, parts};
  } else {
    orders.push({ id: uid(), title, equipId, tech, date, status, desc, parts, createdAt: Date.now() });
  }
  saveState(); renderOrders(); renderDashboard(); closeOrderModal();
}
function deleteOrder(id){
  if(confirm('Excluir esta OS?')){
    orders = orders.filter(o=>o.id!==id);
    saveState(); renderOrders(); renderDashboard();
  }
}
function statusBadge(s){
  switch(s){
    case 'aberta': return '<span class="badge open">Aberta</span>';
    case 'andamento': return '<span class="badge progress">Em andamento</span>';
    case 'concluida': return '<span class="badge done">Concluída</span>';
    default: return s;
  }
}
function renderOrders(){
  const q = document.getElementById('orderSearch').value.toLowerCase();
  const st = document.getElementById('orderStatusFilter').value;
  let list = orders.slice().sort((a,b)=> (b.createdAt||0)-(a.createdAt||0));
  if(st) list = list.filter(o=>o.status===st);
  if(q) list = list.filter(o => (o.title+' '+(o.tech||'')+' '+equipName(o.equipId)).toLowerCase().includes(q));
  const el = document.getElementById('ordersList');
  if(list.length===0){ el.innerHTML = '<div class="card-full"><p>Nenhuma ordem cadastrada.</p></div>'; return; }
  const rows = list.map(o=>`
    <tr>
      <td><strong>${o.title}</strong><br><small>${equipName(o.equipId)}</small></td>
      <td>${o.tech||'-'}</td>
      <td>${fmtDate(o.date)}</td>
      <td>${statusBadge(o.status)}</td>
      <td>
        <button class="btn" onclick="openOrderModal('${o.id}')">Editar</button>
        <button class="btn danger" onclick="deleteOrder('${o.id}')">Excluir</button>
      </td>
    </tr>`).join('');
  el.innerHTML = `<table>
    <thead><tr><th>Título / Equipamento</th><th>Técnico</th><th>Data</th><th>Status</th><th>Ações</th></tr></thead>
    <tbody>${rows}</tbody></table>`;
}
function equipName(id){ const e = equips.find(x=>x.id===id); return e? e.name : '(removido)'; }

// ===== Dashboard =====
function renderDashboard(){
  const now = new Date();
  const m = now.getMonth(), y = now.getFullYear();
  const doneThisMonth = orders.filter(o=> o.status==='concluida' && o.date && (new Date(o.date+'T00:00:00').getMonth()===m) && (new Date(o.date+'T00:00:00').getFullYear()===y)).length;
  document.getElementById('count-open').textContent = orders.filter(o=>o.status==='aberta').length;
  document.getElementById('count-progress').textContent = orders.filter(o=>o.status==='andamento').length;
  document.getElementById('count-done').textContent = doneThisMonth;
  document.getElementById('count-equip').textContent = equips.length;
}

// ===== Backup =====
function exportBackup(){
  const data = { equips, orders, exportedAt: new Date().toISOString() };
  const blob = new Blob([JSON.stringify(data,null,2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'manutech-backup.json'; a.click();
  URL.revokeObjectURL(url);
}
function importBackup(){
  const file = document.getElementById('importFile').files[0];
  if(!file) return alert('Selecione um arquivo JSON.');
  const reader = new FileReader();
  reader.onload = () => {
    try{
      const data = JSON.parse(reader.result);
      if(!data.equips || !data.orders) throw new Error('Arquivo inválido');
      equips = data.equips; orders = data.orders; saveState();
      renderEquipments(); renderOrders(); renderDashboard();
      alert('Backup importado com sucesso!');
    }catch(e){ alert('Erro ao importar: '+e.message); }
  };
  reader.readAsText(file);
}

// ===== Inicialização =====
window.addEventListener('DOMContentLoaded', () => {
  renderDashboard();
});
